import React from "react";

const Qualitie = ({ color, name, _id }) => {

};

export default Qualitie;
