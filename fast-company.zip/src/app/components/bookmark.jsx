import React from "react";

const BookMark = ({ status, ...rest }) => {

};

export default BookMark;
